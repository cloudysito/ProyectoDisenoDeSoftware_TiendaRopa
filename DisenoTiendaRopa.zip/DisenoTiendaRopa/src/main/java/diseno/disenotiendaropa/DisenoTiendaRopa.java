/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package diseno.disenotiendaropa;

import ControlPantallas.ControlPantallas;
import DisenoGUIs.GUIInicioSesion;

/**
 *
 * @author emiim
 */
public class DisenoTiendaRopa {

    public static void main(String[] args) {
        ControlPantallas.getInstase().iniciarFlujo();
    }
}
